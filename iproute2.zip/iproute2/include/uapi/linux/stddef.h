/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */


#ifndef __always_inline
#define __always_inline __inline__
#endif
