static const char SNAPSHOT[] = "200602";
